<!-- All JavaScript files
    ================================================== -->
<script src="<?php echo e(asset('frontend/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/bootstrap.min.js')); ?>"></script>

<!-- Plugins for this template -->
<script src="<?php echo e(asset('frontend/js/jquery-plugin-collection.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/js/jquery.mCustomScrollbar.js')); ?>"></script>

<!-- Custom script for this template -->
<script src="<?php echo e(asset('frontend/js/script.js')); ?>"></script>
</body>


</html>
<?php /**PATH D:\laravel_projects\cms-project\resources\views/frontend/partials/foot.blade.php ENDPATH**/ ?>