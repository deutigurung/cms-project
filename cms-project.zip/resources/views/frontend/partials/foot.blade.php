<!-- All JavaScript files
    ================================================== -->
<script src="{{ asset('frontend/js/jquery.min.js') }}"></script>
<script src="{{ asset('frontend/js/bootstrap.min.js') }}"></script>

<!-- Plugins for this template -->
<script src="{{ asset('frontend/js/jquery-plugin-collection.js') }}"></script>
<script src="{{ asset('frontend/js/jquery.mCustomScrollbar.js') }}"></script>

<!-- Custom script for this template -->
<script src="{{ asset('frontend/js/script.js') }}"></script>
</body>


</html>
